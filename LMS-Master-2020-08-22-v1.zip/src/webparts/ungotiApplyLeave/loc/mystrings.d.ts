declare interface IUngotiApplyLeaveWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'UngotiApplyLeaveWebPartStrings' {
  const strings: IUngotiApplyLeaveWebPartStrings;
  export = strings;
}
