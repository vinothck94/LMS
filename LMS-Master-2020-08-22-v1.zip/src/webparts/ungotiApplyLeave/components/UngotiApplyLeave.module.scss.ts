/* tslint:disable */
require("./UngotiApplyLeave.module.css");
const styles = {
  ungotiApplyLeave: 'ungotiApplyLeave_e710e62a',
  container: 'container_e710e62a',
  row: 'row_e710e62a',
  column: 'column_e710e62a',
  'ms-Grid': 'ms-Grid_e710e62a',
  title: 'title_e710e62a',
  subTitle: 'subTitle_e710e62a',
  description: 'description_e710e62a',
  button: 'button_e710e62a',
  label: 'label_e710e62a'
};

export default styles;
/* tslint:enable */