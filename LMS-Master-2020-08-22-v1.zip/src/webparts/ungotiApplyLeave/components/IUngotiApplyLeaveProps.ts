export interface IUngotiApplyLeaveProps {
  description: string;
  siteUrl: string;
}
