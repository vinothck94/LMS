export interface IUngotiApplyLeaveProps {
    description: string;
    siteUrl: string;
}
//# sourceMappingURL=IUngotiApplyLeaveProps.d.ts.map