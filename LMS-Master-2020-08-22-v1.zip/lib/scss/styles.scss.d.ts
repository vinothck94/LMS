declare const styles: {};
export default styles;
//# sourceMappingURL=styles.scss.d.ts.map