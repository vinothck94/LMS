declare const styles: {
    mobilePreviewRotateIcon: string;
};
export default styles;
//# sourceMappingURL=MobilePreviewRotate.module.scss.d.ts.map