declare const styles: {
    canvasHost: string;
    belowHeader: string;
    content: string;
    hasHeader: string;
    hasCommandBar: string;
    NavPane: string;
};
export default styles;
//# sourceMappingURL=CanvasHost.module.scss.d.ts.map