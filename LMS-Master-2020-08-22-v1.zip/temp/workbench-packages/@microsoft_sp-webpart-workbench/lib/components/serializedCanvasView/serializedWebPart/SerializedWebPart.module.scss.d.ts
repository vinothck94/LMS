declare const styles: {
    serializedWebPartItem: string;
};
export default styles;
//# sourceMappingURL=SerializedWebPart.module.scss.d.ts.map