export default function getPublic(req: any, res: any): void;
//# sourceMappingURL=getPublic.d.ts.map